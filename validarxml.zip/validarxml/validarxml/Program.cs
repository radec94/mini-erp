﻿using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Text;

namespace validarxml
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isValid = false;
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, "xsd2.xsd");
            settings.ValidationType = ValidationType.Schema;
            XmlDocument document = new XmlDocument();
            document.Load("xsd2.xml");
            XmlReader rdr = XmlReader.Create(new StringReader(document.InnerXml), settings);

            while (rdr.Read())
            {

            }
            isValid = true;
        }
    }
}
