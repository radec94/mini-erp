﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic  ;

namespace ObtenirNomDeFitxer
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnSeleccionar_Click(object sender, EventArgs e)
        {
            string nomFitxer;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                nomFitxer=openFileDialog1.FileName;
                MessageBox.Show(nomFitxer);
            }
        }

        private void btnLlegir_Click(object sender, EventArgs e)
        {
            string cPrv;
            cPrv=Interaction.InputBox("ENTRA EL CODI DE PROVEÏDOR : ","Llegim Proveïdor");
            if (cPrv == "") MessageBox.Show("No has entrat res");
            else MessageBox.Show("HAS ENTRAT: " + cPrv);

        }
    }
}
