﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.Odbc;
using System.Xml;
using System.Xml.Schema;
using System.Xml.XPath;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using Microsoft.VisualBasic;
using System.Diagnostics;
namespace MiniERP
{
    public partial class frmERP : Form
    {
        public const string CONNECTIONSTRING = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

        private OdbcConnection cn;
        private OdbcDataAdapter da;
        DataSet ds;

        public frmERP()
        {
            cn = new OdbcConnection(CONNECTIONSTRING);
            cn.Open();
            InitializeComponent();
        }

        private void frmERP_Load(object sender, EventArgs e)
        {

        }

        private void exportarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void articlesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //ImportarArticles
            if (ValidarXML("articles.xml", "articles.xsd")) ImportarArticles();
        }

        #region IMPORTAR I ALTRES

        private void ImportarArticles()
        {
            string connectionString;

            //Extreiem del XML:
            string codi = "";
            string descripcio = "";
            int preu = 0;
            int estoc = 0;

            //connectem amb la base de dades
            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            //Seleccionem les dades

            XmlDocument xml = new XmlDocument();

            xml.Load("articles.xml");

            XmlNodeList xnList = xml.SelectNodes("/articles/article");

            foreach (XmlNode xn in xnList)
            {
                try
                {
                    codi = xn["codi"].InnerText;

                    descripcio = xn["descripcio"].InnerText;

                    estoc = Convert.ToInt32(xn["estoc"].InnerText);

                    preu = Convert.ToInt32(xn["preu"].InnerText);

                    // PER FER UN INSERT O UPDATE

                    OdbcCommand cmd = new OdbcCommand();

                    cmd.Connection = ConnexioMySQL;

                    cmd.CommandText = "INSERT INTO article VALUES ('" + codi + "','" + descripcio + "','" + estoc + "','" + preu + "');";

                    cmd.ExecuteNonQuery();
                }
                catch (Exception)
                {
                    AfegirError("L'ARTICLE AMB CODI: " + codi + " JA EXISTEIX A LA TAULA MESTRE D'ARTICLES", "IMPORTAR ARTICLES");
                }

            }

            ConnexioMySQL.Close();
            
        } 

        private void ImportarProveidors()
        {
            string connectionString;

            //Extreiem del XML:
            string codi = "";
            string nom = "";
            string adreca = "";
            string poblacio = "";
            int cp = 0;

            //connectem amn la base de dades
            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            //Seleccionem les dades

            XmlDocument xml = new XmlDocument();

            xml.Load("proveidors.xml");

            XmlNodeList xnList = xml.SelectNodes("/proveidors/proveidor");

            foreach (XmlNode xn in xnList)
            {
                try
                {
                    codi = xn["codi"].InnerText;

                    nom = xn["nom"].InnerText;

                    adreca = xn["adreca"].InnerText;

                    poblacio = xn["poblacio"].InnerText;

                    cp = Convert.ToInt32(xn["cp"].InnerText);

                    // PER FER UN INSERT O UPDATE

                    OdbcCommand cmd = new OdbcCommand();

                    cmd.Connection = ConnexioMySQL;

                    cmd.CommandText = "INSERT INTO proveidor VALUES ('" + codi + "','" + nom + "','" + adreca + "','" + poblacio + "','" + cp + "');";

                    cmd.ExecuteNonQuery();
                }
                catch (Exception )
                {
                    AfegirError("EL PROVEIDOR AMB CODI: " + codi + " JA EXISTEIX A LA TAULA MESTRE DE PROVEIDORS", "IMPORTAR PROVEIDOR");
                    //nO REGISTRE EL MPRIMER CODI
                }

            }

            ConnexioMySQL.Close();

        } 

        private void ImportarCapçaleraComanda(string nomFitxer)
        {
            string connectionString;

            //Extreiem del XML:
            string codiProveidor = "";
            string data = "";

            //connectem amb la base de dades

            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            //Seleccionem les dades

            XmlDocument xml = new XmlDocument();

            xml.Load(nomFitxer);//Nom de la variable que assigna el nom de la comanda----------------------------------

            XmlNodeList xnList = xml.SelectNodes("/comanda");

            foreach (XmlNode xn in xnList)
            {
                try
                {
                    codiProveidor = xn["codiProveidor"].InnerText;

                    data = xn["data"].InnerText;

                    // PER FER UN INSERT O UPDATE

                    OdbcCommand cmd = new OdbcCommand();

                    cmd.Connection = ConnexioMySQL;

                    cmd.CommandText = "INSERT INTO ccomanda (codiproveidor,data) VALUES ('" + codiProveidor + "','" + data + "');";

                    cmd.ExecuteNonQuery();


                }
                catch (Exception)//Proveïdor inexistent a la taula PROVEIDOR. Genera error sobre fitxer XML
                {
                    AfegirError("Proveïdor inexistent a la taula PROVEIDOR " + codiProveidor, "INCORPORAR COMANDA");
                    //nO REGISTRE EL MPRIMER CODI
                }

            }

            ConnexioMySQL.Close();
        }   

        private void ImportarDetallComanda(string nomFitxer)
        {
            string connectionString;

            //Extreiem del XML:
            ulong codiComanda = 0;
            string codiArticle = "";
            ulong quantitat = 0;
            int preu = 0;
            string rebuttext = "";
            bool rebut = false;
            int fila;

            //connectem amb la base de dades

            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            //Seleccionem les dades
            //PER SELECCIONAR DADES

            //crea el datadapter. No cal si el que volem son inserts

            OdbcDataAdapter da;

            da = new OdbcDataAdapter("Select codi, codiproveidor ,data  from ccomanda", ConnexioMySQL);

            //omples el dataset amb les dades del da. No cal si e lque volem son inserts

            DataSet ds = new DataSet();

            da.Fill(ds);

            //ds.Tables[0].Rows.Count número de fila

            //Rows té tantes files com registres el select i tantes columnes com camps

            XmlDocument xml = new XmlDocument();

            xml.Load(nomFitxer);//Nom de la variable que assigna el nom de la comanda----------------------------------

            XmlNodeList xnList = xml.SelectNodes("/comanda/articles/article");

            foreach (XmlNode xn in xnList)
            {
                try
                {
                    fila = ds.Tables[0].Rows.Count - 1;

                    codiComanda = Convert.ToUInt64(ds.Tables[0].Rows[fila][0].ToString());

                    codiArticle = xn["codiArticle"].InnerText;

                    quantitat = Convert.ToUInt64(xn["quantitat"].InnerText);

                    preu = Convert.ToInt32(xn["preu"].InnerText);

                    rebuttext = xn["rebut"].InnerText;

                    if (rebuttext[0] == 'S' || rebuttext[1] == 'i') rebut = true;
                    else rebut = false;

                    // PER FER UN INSERT O UPDATE

                    OdbcCommand cmd = new OdbcCommand();

                    cmd.Connection = ConnexioMySQL;

                    cmd.CommandText = "INSERT INTO dcomanda VALUES (" + codiComanda + ",'" + codiArticle + "'," + quantitat + "," + preu + "," + rebut + ");";
                    cmd.ExecuteNonQuery();


                }
                catch (Exception)//Proveïdor inexistent a la taula PROVEIDOR. Genera error sobre fitxer XML
                {
                    AfegirError("Article inexistent a la taula ARTICLES " + codiArticle, "INCORPORAR COMANDA");
                    //nO REGISTRE EL MPRIMER CODI
                }

            }

            ConnexioMySQL.Close();
        }      

        private void ImportarCapçaleraAlbara(string nomFitxer)
        {
            string connectionString;

            //Extreiem del XML:
            ulong codiComanda = 0;
            string data = "";

            //connectem amb la base de dades

            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            //Seleccionem les dades

            XmlDocument xml = new XmlDocument();

            xml.Load(nomFitxer);//Nom de la variable que assigna el nom de la comanda----------------------------------

            XmlNodeList xnList = xml.SelectNodes("/albara");

            foreach (XmlNode xn in xnList)
            {
                try
                {
                    codiComanda = Convert.ToUInt64(xn["codiComanda"].InnerText);

                    data = xn["data"].InnerText;

                    // PER FER UN INSERT O UPDATE

                    OdbcCommand cmd = new OdbcCommand();

                    cmd.Connection = ConnexioMySQL;

                    cmd.CommandText = "INSERT INTO calbara (codiComanda,data) VALUES ('" + codiComanda + "','" + data + "');";


                    cmd.ExecuteNonQuery();


                }
                catch (Exception)//Proveïdor inexistent a la taula PROVEIDOR. Genera error sobre fitxer XML
                {
                    AfegirError("L'albara esta a associat a al codi de comanda " + codiComanda + " inexistent", "INCORPORAR COMANDA");
                    //nO REGISTRE EL MPRIMER CODI
                }

            }

            ConnexioMySQL.Close();
        }   

        private void ImportarDetallAlbara(string nomFitxer)
        {
            string connectionString;

            //Extreiem del XML:
            ulong codiAlbara = 0;
            string codiArticle = "";
            ulong quantitat = 0;
            int preu = 0;

            int fila;
            
            //connectem amb la base de dades

            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            //Seleccionem les dades
            //PER SELECCIONAR DADES

            //crea el datadapter. No cal si el que volem son inserts

            OdbcDataAdapter da;

            da = new OdbcDataAdapter("Select codi, codicomanda ,data  from calbara", ConnexioMySQL);

            //omples el dataset amb les dades del da. No cal si e lque volem son inserts

            DataSet ds = new DataSet();

            da.Fill(ds);

            //ds.Tables[0].Rows.Count número de fila

            //Rows té tantes files com registres el select i tantes columnes com camps

            XmlDocument xml = new XmlDocument();

            xml.Load(nomFitxer);//Nom de la variable que assigna el nom de la comanda----------------------------------

            XmlNodeList xnList = xml.SelectNodes("/albara/articles/article");

            foreach (XmlNode xn in xnList)
            {
                try
                {
                    fila = ds.Tables[0].Rows.Count - 1;

                    codiAlbara = Convert.ToUInt64(ds.Tables[0].Rows[fila][0].ToString());

                    codiArticle = xn["codiArticle"].InnerText;

                    quantitat = Convert.ToUInt64(xn["quantitat"].InnerText);

                    preu = Convert.ToInt32(xn["preu"].InnerText);

                    // PER FER UN INSERT O UPDATE

                    OdbcCommand cmd = new OdbcCommand();

                    cmd.Connection = ConnexioMySQL;

                    cmd.CommandText = "INSERT INTO dalbara VALUES (" + codiAlbara + ",'" + codiArticle + "'," + quantitat + "," + preu + ");";
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "UPDATE article SET estoc = estoc + " + quantitat + " WHERE codi = '" + codiArticle + "';";
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "UPDATE dcomanda SET rebut = true WHERE codiarticle = '" + codiArticle + "';";
                    cmd.ExecuteNonQuery();

                }

                catch (Exception)//Proveïdor inexistent a la taula PROVEIDOR. Genera error sobre fitxer XML
                {
                    AfegirError("L'article associat a l'albara amb codi " + codiArticle + "no esta registrat a la comanda", "INCORPORAR COMANDA");
                    //nO REGISTRE EL MPRIMER CODI
                }

               
             }
            ConnexioMySQL.Close();
        }

        private void crearFitxerError()
        {
            StreamWriter arxiu = new StreamWriter("errors.xml", false);

            arxiu.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");

            arxiu.WriteLine("<errors>");

            arxiu.WriteLine("</errors>");

            arxiu.Close();
        }

        private void AfegirError(string descripcio, string proces)
        {

            try
            {
                //CARREGUEM EN MEMÒRIA EL FITXER D'ERRORS

                XmlDocument doc = new XmlDocument();

                doc.Load("errors.xml");

                //root representa l'arrel del document: <errors>

                XmlNode root = doc.DocumentElement;

                //CREEM UN NOU NODE D'ERROR  <error></error>

                XmlElement elem = doc.CreateElement("error");

                //CREEM SUBNODES FILL DE L'ERROR, TANTS COM NECESSITEM PER PRECISSAR 
                //DETALLS DE L'ERROR: DATA, PROCES QUE L'HA GENERAT, DESCRIPCIÓ ...

                XmlElement subElement1 = doc.CreateElement("descripcio");

                subElement1.InnerText = descripcio;

                XmlElement subElement2 = doc.CreateElement("proces");

                subElement2.InnerText = proces;

                //AFEGIM ELS SUBELEMENTS COM A FILLS DE l'ETIQUETA <error>

                elem.AppendChild(subElement1);

                elem.AppendChild(subElement2);

                //AFEGIM el nou error com a nou fill de l'arrel <errors>

                root.AppendChild(elem);

                //ACTUALITZEM EL DOCUMENT A DISC (FINS ARA TOT ES FEIA A MEMÒRIA)

                doc.Save("errors.xml");
            }
            catch (Exception)
            {
                StreamWriter arxiu = new StreamWriter("errors.xml", false);

                arxiu.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");

                arxiu.WriteLine("<errors>");

                arxiu.WriteLine("</errors>");

                arxiu.Close();
            }
        }

        private string LlegirURL()
        {
            string nomFitxer = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                nomFitxer = openFileDialog1.FileName;
                MessageBox.Show(nomFitxer);
            }
            return nomFitxer;
        }

        private static bool ValidarXML(string xml, string xsd)
        {
            bool isValid = false;
            try
            {

                XmlReaderSettings settings = new XmlReaderSettings();
                settings.Schemas.Add(null, xsd);
                settings.ValidationType = ValidationType.Schema;
                XmlDocument document = new XmlDocument();
                document.Load(xml);
                XmlReader rdr = XmlReader.Create(new StringReader(document.InnerXml), settings);

                while (rdr.Read())
                {

                }
                isValid = true;
            }

            catch (Exception)
            {
                MessageBox.Show("FITXER XML DE " + xml + ".xml NO VÀLID", "ERROR");
                isValid = false;

            }
            return isValid;
        }

        #endregion

        #region Accions Exportar i Llistar

        private void ViewXML(string xml)
        {
            Process pr = new Process();
            try
            {
                pr.StartInfo.FileName = @xml + ".xml";
                pr.Start();
            }
            catch (NullReferenceException ex)
            {
                MessageBox.Show(ex.Message, ("Error l'arxiu no existeix en el context."));
            }
        }

        private void ExportarArticles()
        {
            string connectionString;
            StreamWriter arxiu = new StreamWriter("articlesExport.xml", false);
            string codi = "";
            string desc = "";
            int estoc = 0;
            int preu = 0;

            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            OdbcDataAdapter da;

            da = new OdbcDataAdapter("Select codi, descripcio ,estoc, preu  from article", ConnexioMySQL);

            DataSet ds = new DataSet();

            da.Fill(ds);

            arxiu.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");

            arxiu.WriteLine("<articles>");

            for (int fila = 0; fila < ds.Tables[0].Rows.Count; fila++)
            {

                codi = (string)ds.Tables[0].Rows[fila][0];
                desc = (string)ds.Tables[0].Rows[fila][1];
                estoc = Convert.ToInt32(ds.Tables[0].Rows[fila][2]);
                preu = Convert.ToInt32(ds.Tables[0].Rows[fila][3]);
                arxiu.WriteLine("\t<article>");
                arxiu.WriteLine("\t\t<codi>" + codi + "</codi>");
                arxiu.WriteLine("\t\t<descripcio>" + desc + "</descripcio>");
                arxiu.WriteLine("\t\t<estoc>" + estoc + "</estoc>");
                arxiu.WriteLine("\t\t<preu>" + codi + "</preu>");
                arxiu.WriteLine("\t</article>");
            }

            arxiu.WriteLine("</articles>");
            arxiu.Close();
            ConnexioMySQL.Close();
        }

        private void ExportarProveidors()
        {
            string connectionString;
            StreamWriter arxiu = new StreamWriter("proveidorsExport.xml", false);
            string codi = "";
            string nom = "";
            string adress = "";
            string pobl = "";
            string cp = "";

            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            OdbcDataAdapter da;

            da = new OdbcDataAdapter("Select codi, nom , adreça, poblacio, cp  from proveidor", ConnexioMySQL);

            DataSet ds = new DataSet();

            da.Fill(ds);

            arxiu.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");

            arxiu.WriteLine("<proveidors>");

            for (int fila = 0; fila < ds.Tables[0].Rows.Count; fila++)
            {

                codi = (string)ds.Tables[0].Rows[fila][0];
                nom = (string)ds.Tables[0].Rows[fila][1];
                adress = (string)ds.Tables[0].Rows[fila][2];
                pobl = (string)ds.Tables[0].Rows[fila][3];
                cp = (string)ds.Tables[0].Rows[fila][4];
                arxiu.WriteLine("\t<proveidor>");
                arxiu.WriteLine("\t\t<codi>" + codi + "</codi>");
                arxiu.WriteLine("\t\t<nom>" + nom + "</nom>");
                arxiu.WriteLine("\t\t<adreça>" + adress + "</adreça>");
                arxiu.WriteLine("\t\t<poblacio>" + pobl + "</poblacio>");
                arxiu.WriteLine("\t\t<cp>" + cp + "</cp>");
                arxiu.WriteLine("\t</proveidor>");
            }

            arxiu.WriteLine("</proveidors>");
            arxiu.Close();
            ConnexioMySQL.Close();
        }

        private void ExportarArticlesPendents()
        {
            string connectionString;
            StreamWriter arxiu = new StreamWriter("articlesPendentsExport.xml", false);
            int codiComanda = 0;
            string codiArticle = "";
            int quant = 0;
            int preu = 0;
            bool rebut = false;

            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            OdbcDataAdapter da;

            da = new OdbcDataAdapter("Select codicomanda, codiarticle , quantitat, preu, rebut  from dcomanda", ConnexioMySQL);

            DataSet ds = new DataSet();

            da.Fill(ds);

            arxiu.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");

            arxiu.WriteLine("<articles>");

            for (int fila = 0; fila < ds.Tables[0].Rows.Count; fila++)
            {

                codiComanda = Convert.ToInt32(ds.Tables[0].Rows[fila][0]);
                codiArticle = (string)ds.Tables[0].Rows[fila][1];
                quant = Convert.ToInt32(ds.Tables[0].Rows[fila][2]);
                preu = Convert.ToInt32(ds.Tables[0].Rows[fila][3]);
                rebut = (bool)ds.Tables[0].Rows[fila][4];

                if (rebut == false)
                {
                    arxiu.WriteLine("\t<article>");
                    arxiu.WriteLine("\t\t<codiComanda>" + codiComanda + "</codiComanda>");
                    arxiu.WriteLine("\t\t<codiArticle>" + codiArticle + "</codiArticle>");
                    arxiu.WriteLine("\t\t<quantitat>" + quant + "</quantitat>");
                    arxiu.WriteLine("\t\t<preu>" + preu + "</preu>");
                    arxiu.WriteLine("\t\t<rebut> No </rebut>");
                    arxiu.WriteLine("\t</article>");
                }
            }

            arxiu.WriteLine("</articles>");
            arxiu.Close();
            ConnexioMySQL.Close();
        }

        private void ExportarValorEstoc()
        {
            string connectionString;
            StreamWriter arxiu = new StreamWriter("estocValorat.xml", false);
            string codi = "";
            string desc = "";
            int estoc = 0;
            int preu = 0;
            int preuTotal = 0;
            int countEstoc = 0, countPreuTotal = 0;


            connectionString = "Driver={Microsoft Access Driver (*.mdb)};DBQ=minierp.mdb";

            OdbcConnection ConnexioMySQL = new OdbcConnection(connectionString);

            ConnexioMySQL.Open();

            OdbcDataAdapter da;

            da = new OdbcDataAdapter("Select codi, descripcio ,estoc, preu  from article", ConnexioMySQL);

            DataSet ds = new DataSet();

            da.Fill(ds);

            arxiu.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");

            arxiu.WriteLine("<articles>");

            for (int fila = 0; fila < ds.Tables[0].Rows.Count; fila++)
            {

                codi = (string)ds.Tables[0].Rows[fila][0];
                desc = (string)ds.Tables[0].Rows[fila][1];
                estoc = Convert.ToInt32(ds.Tables[0].Rows[fila][2]);
                preu = Convert.ToInt32(ds.Tables[0].Rows[fila][3]);
                preuTotal = estoc * preu;
                countEstoc += estoc;
                countPreuTotal += preu;

                arxiu.WriteLine("\t<article>");
                arxiu.WriteLine("\t\t<codi>" + codi + "</codi>");
                arxiu.WriteLine("\t\t<descripcio>" + desc + "</descripcio>");
                arxiu.WriteLine("\t\t<estoc>" + estoc + "</estoc>");
                arxiu.WriteLine("\t\t<preu>" + codi + "</preu>");
                arxiu.WriteLine("\t\t<preuTotal>" + preuTotal + "</preu>");
                arxiu.WriteLine("\t</article>");
            }


            arxiu.WriteLine("<estocTotal>" + countEstoc + "</estocTotal>");
            arxiu.WriteLine("<valorMagatzem>" + (countEstoc * countPreuTotal) + "</valorMagatzem>");
            arxiu.WriteLine("</articles>");
            arxiu.Close();
            ConnexioMySQL.Close();
        }

        #endregion

        private void proveïdorsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (ValidarXML("proveidors.xml", "proveidors.xsd")) ImportarProveidors();
        }

        private void incorporarComandaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            string nomFitxer = "";
            nomFitxer = LlegirURL();
            if (ValidarXML(nomFitxer, "comandes.xsd"))
            {
                ImportarCapçaleraComanda(nomFitxer);
                ImportarDetallComanda(nomFitxer);
            }
           
        }

        private void recepcionarAlbaràToolStripMenuItem_Click(object sender, EventArgs e)
        {
             string nomFitxer = "";
            nomFitxer = LlegirURL();
            if (ValidarXML(nomFitxer, "albara.xsd"))
            {
                ImportarCapçaleraAlbara(nomFitxer);
                ImportarDetallAlbara(nomFitxer);

            }
            
        }

        private void articlesToolStripMenuItem2_Click_1(object sender, EventArgs e)
        {
            ExportarArticles();
            ViewXML("articlesExport");
        }

        private void articlesPendentsDeRebreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportarArticlesPendents();
            ViewXML("articlesPendentsExport");
        }

        private void estocValoratToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportarValorEstoc();
            ViewXML("estocValorat");
        }

        private void proveïdorsToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ExportarProveidors();
            ViewXML("proveidorsExport");
        }

        private void proveïdorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportarProveidors();
        }

        private void articlesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportarArticles();
        }

        private void articlesPendentsPerProveïdorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportarArticlesPendents();
        }

        private void valoracióStockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportarValorEstoc();
        }
   }
}

